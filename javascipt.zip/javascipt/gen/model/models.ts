import localVarRequest from 'request';

export * from './baseFilterV4';
export * from './baseProduct';
export * from './breakPrice';
export * from './categoriesResponse';
export * from './category';
export * from './categoryNode';
export * from './categoryResponse';
export * from './classifications';
export * from './dKProblemDetails';
export * from './description';
export * from './digiReelPricing';
export * from './filterId';
export * from './filterOptions';
export * from './filterOptionsRequest';
export * from './filterValue';
export * from './isoSearchLocale';
export * from './keywordRequest';
export * from './keywordResponse';
export * from './manufacturer';
export * from './manufacturerInfo';
export * from './manufacturersResponse';
export * from './mediaLinks';
export * from './mediaResponse';
export * from './packageType';
export * from './packageTypeByQuantityProduct';
export * from './packageTypeByQuantityResponse';
export * from './parameter';
export * from './parameterFilterOptionsResponse';
export * from './parameterFilterRequest';
export * from './parameterValue';
export * from './parametricCategory';
export * from './priceBreak';
export * from './product';
export * from './productAssociations';
export * from './productAssociationsResponse';
export * from './productDetails';
export * from './productStatusV4';
export * from './productSubstitute';
export * from './productSubstitutesResponse';
export * from './productSummary';
export * from './productVariation';
export * from './recommendation';
export * from './recommendedProduct';
export * from './recommendedProductsResponse';
export * from './series';
export * from './sortOptions';
export * from './supplier';
export * from './topCategory';
export * from './topCategoryNode';

import * as fs from 'fs';

export interface RequestDetailedFile {
    value: Buffer;
    options?: {
        filename?: string;
        contentType?: string;
    }
}

export type RequestFile = string | Buffer | fs.ReadStream | RequestDetailedFile;


import { BaseFilterV4 } from './baseFilterV4';
import { BaseProduct } from './baseProduct';
import { BreakPrice } from './breakPrice';
import { CategoriesResponse } from './categoriesResponse';
import { Category } from './category';
import { CategoryNode } from './categoryNode';
import { CategoryResponse } from './categoryResponse';
import { Classifications } from './classifications';
import { DKProblemDetails } from './dKProblemDetails';
import { Description } from './description';
import { DigiReelPricing } from './digiReelPricing';
import { FilterId } from './filterId';
import { FilterOptions } from './filterOptions';
import { FilterOptionsRequest } from './filterOptionsRequest';
import { FilterValue } from './filterValue';
import { IsoSearchLocale } from './isoSearchLocale';
import { KeywordRequest } from './keywordRequest';
import { KeywordResponse } from './keywordResponse';
import { Manufacturer } from './manufacturer';
import { ManufacturerInfo } from './manufacturerInfo';
import { ManufacturersResponse } from './manufacturersResponse';
import { MediaLinks } from './mediaLinks';
import { MediaResponse } from './mediaResponse';
import { PackageType } from './packageType';
import { PackageTypeByQuantityProduct } from './packageTypeByQuantityProduct';
import { PackageTypeByQuantityResponse } from './packageTypeByQuantityResponse';
import { Parameter } from './parameter';
import { ParameterFilterOptionsResponse } from './parameterFilterOptionsResponse';
import { ParameterFilterRequest } from './parameterFilterRequest';
import { ParameterValue } from './parameterValue';
import { ParametricCategory } from './parametricCategory';
import { PriceBreak } from './priceBreak';
import { Product } from './product';
import { ProductAssociations } from './productAssociations';
import { ProductAssociationsResponse } from './productAssociationsResponse';
import { ProductDetails } from './productDetails';
import { ProductStatusV4 } from './productStatusV4';
import { ProductSubstitute } from './productSubstitute';
import { ProductSubstitutesResponse } from './productSubstitutesResponse';
import { ProductSummary } from './productSummary';
import { ProductVariation } from './productVariation';
import { Recommendation } from './recommendation';
import { RecommendedProduct } from './recommendedProduct';
import { RecommendedProductsResponse } from './recommendedProductsResponse';
import { Series } from './series';
import { SortOptions } from './sortOptions';
import { Supplier } from './supplier';
import { TopCategory } from './topCategory';
import { TopCategoryNode } from './topCategoryNode';

/* tslint:disable:no-unused-variable */
let primitives = [
                    "string",
                    "boolean",
                    "double",
                    "integer",
                    "long",
                    "float",
                    "number",
                    "any"
                 ];

let enumsMap: {[index: string]: any} = {
        "FilterOptions.MarketPlaceFiltersEnum": FilterOptions.MarketPlaceFiltersEnum,
        "FilterOptionsRequest.MarketPlaceFilterEnum": FilterOptionsRequest.MarketPlaceFilterEnum,
        "FilterOptionsRequest.SearchOptionsEnum": FilterOptionsRequest.SearchOptionsEnum,
        "FilterValue.RangeFilterTypeEnum": FilterValue.RangeFilterTypeEnum,
        "ParameterValue.ParameterTypeEnum": ParameterValue.ParameterTypeEnum,
        "SortOptions.FieldEnum": SortOptions.FieldEnum,
        "SortOptions.SortOrderEnum": SortOptions.SortOrderEnum,
}

let typeMap: {[index: string]: any} = {
    "BaseFilterV4": BaseFilterV4,
    "BaseProduct": BaseProduct,
    "BreakPrice": BreakPrice,
    "CategoriesResponse": CategoriesResponse,
    "Category": Category,
    "CategoryNode": CategoryNode,
    "CategoryResponse": CategoryResponse,
    "Classifications": Classifications,
    "DKProblemDetails": DKProblemDetails,
    "Description": Description,
    "DigiReelPricing": DigiReelPricing,
    "FilterId": FilterId,
    "FilterOptions": FilterOptions,
    "FilterOptionsRequest": FilterOptionsRequest,
    "FilterValue": FilterValue,
    "IsoSearchLocale": IsoSearchLocale,
    "KeywordRequest": KeywordRequest,
    "KeywordResponse": KeywordResponse,
    "Manufacturer": Manufacturer,
    "ManufacturerInfo": ManufacturerInfo,
    "ManufacturersResponse": ManufacturersResponse,
    "MediaLinks": MediaLinks,
    "MediaResponse": MediaResponse,
    "PackageType": PackageType,
    "PackageTypeByQuantityProduct": PackageTypeByQuantityProduct,
    "PackageTypeByQuantityResponse": PackageTypeByQuantityResponse,
    "Parameter": Parameter,
    "ParameterFilterOptionsResponse": ParameterFilterOptionsResponse,
    "ParameterFilterRequest": ParameterFilterRequest,
    "ParameterValue": ParameterValue,
    "ParametricCategory": ParametricCategory,
    "PriceBreak": PriceBreak,
    "Product": Product,
    "ProductAssociations": ProductAssociations,
    "ProductAssociationsResponse": ProductAssociationsResponse,
    "ProductDetails": ProductDetails,
    "ProductStatusV4": ProductStatusV4,
    "ProductSubstitute": ProductSubstitute,
    "ProductSubstitutesResponse": ProductSubstitutesResponse,
    "ProductSummary": ProductSummary,
    "ProductVariation": ProductVariation,
    "Recommendation": Recommendation,
    "RecommendedProduct": RecommendedProduct,
    "RecommendedProductsResponse": RecommendedProductsResponse,
    "Series": Series,
    "SortOptions": SortOptions,
    "Supplier": Supplier,
    "TopCategory": TopCategory,
    "TopCategoryNode": TopCategoryNode,
}

export class ObjectSerializer {
    public static findCorrectType(data: any, expectedType: string) {
        if (data == undefined) {
            return expectedType;
        } else if (primitives.indexOf(expectedType.toLowerCase()) !== -1) {
            return expectedType;
        } else if (expectedType === "Date") {
            return expectedType;
        } else {
            if (enumsMap[expectedType]) {
                return expectedType;
            }

            if (!typeMap[expectedType]) {
                return expectedType; // w/e we don't know the type
            }

            // Check the discriminator
            let discriminatorProperty = typeMap[expectedType].discriminator;
            if (discriminatorProperty == null) {
                return expectedType; // the type does not have a discriminator. use it.
            } else {
                if (data[discriminatorProperty]) {
                    var discriminatorType = data[discriminatorProperty];
                    if(typeMap[discriminatorType]){
                        return discriminatorType; // use the type given in the discriminator
                    } else {
                        return expectedType; // discriminator did not map to a type
                    }
                } else {
                    return expectedType; // discriminator was not present (or an empty string)
                }
            }
        }
    }

    public static serialize(data: any, type: string) {
        if (data == undefined) {
            return data;
        } else if (primitives.indexOf(type.toLowerCase()) !== -1) {
            return data;
        } else if (type.lastIndexOf("Array<", 0) === 0) { // string.startsWith pre es6
            let subType: string = type.replace("Array<", ""); // Array<Type> => Type>
            subType = subType.substring(0, subType.length - 1); // Type> => Type
            let transformedData: any[] = [];
            for (let index = 0; index < data.length; index++) {
                let datum = data[index];
                transformedData.push(ObjectSerializer.serialize(datum, subType));
            }
            return transformedData;
        } else if (type === "Date") {
            return data.toISOString();
        } else {
            if (enumsMap[type]) {
                return data;
            }
            if (!typeMap[type]) { // in case we dont know the type
                return data;
            }

            // Get the actual type of this object
            type = this.findCorrectType(data, type);

            // get the map for the correct type.
            let attributeTypes = typeMap[type].getAttributeTypeMap();
            let instance: {[index: string]: any} = {};
            for (let index = 0; index < attributeTypes.length; index++) {
                let attributeType = attributeTypes[index];
                instance[attributeType.baseName] = ObjectSerializer.serialize(data[attributeType.name], attributeType.type);
            }
            return instance;
        }
    }

    public static deserialize(data: any, type: string) {
        // polymorphism may change the actual type.
        type = ObjectSerializer.findCorrectType(data, type);
        if (data == undefined) {
            return data;
        } else if (primitives.indexOf(type.toLowerCase()) !== -1) {
            return data;
        } else if (type.lastIndexOf("Array<", 0) === 0) { // string.startsWith pre es6
            let subType: string = type.replace("Array<", ""); // Array<Type> => Type>
            subType = subType.substring(0, subType.length - 1); // Type> => Type
            let transformedData: any[] = [];
            for (let index = 0; index < data.length; index++) {
                let datum = data[index];
                transformedData.push(ObjectSerializer.deserialize(datum, subType));
            }
            return transformedData;
        } else if (type === "Date") {
            return new Date(data);
        } else {
            if (enumsMap[type]) {// is Enum
                return data;
            }

            if (!typeMap[type]) { // dont know the type
                return data;
            }
            let instance = new typeMap[type]();
            let attributeTypes = typeMap[type].getAttributeTypeMap();
            for (let index = 0; index < attributeTypes.length; index++) {
                let attributeType = attributeTypes[index];
                instance[attributeType.name] = ObjectSerializer.deserialize(data[attributeType.baseName], attributeType.type);
            }
            return instance;
        }
    }
}

export interface Authentication {
    /**
    * Apply authentication settings to header and query params.
    */
    applyToRequest(requestOptions: localVarRequest.Options): Promise<void> | void;
}

export class HttpBasicAuth implements Authentication {
    public username: string = '';
    public password: string = '';

    applyToRequest(requestOptions: localVarRequest.Options): void {
        requestOptions.auth = {
            username: this.username, password: this.password
        }
    }
}

export class HttpBearerAuth implements Authentication {
    public accessToken: string | (() => string) = '';

    applyToRequest(requestOptions: localVarRequest.Options): void {
        if (requestOptions && requestOptions.headers) {
            const accessToken = typeof this.accessToken === 'function'
                            ? this.accessToken()
                            : this.accessToken;
            requestOptions.headers["Authorization"] = "Bearer " + accessToken;
        }
    }
}

export class ApiKeyAuth implements Authentication {
    public apiKey: string = '';

    constructor(private location: string, private paramName: string) {
    }

    applyToRequest(requestOptions: localVarRequest.Options): void {
        if (this.location == "query") {
            (<any>requestOptions.qs)[this.paramName] = this.apiKey;
        } else if (this.location == "header" && requestOptions && requestOptions.headers) {
            requestOptions.headers[this.paramName] = this.apiKey;
        } else if (this.location == 'cookie' && requestOptions && requestOptions.headers) {
            if (requestOptions.headers['Cookie']) {
                requestOptions.headers['Cookie'] += '; ' + this.paramName + '=' + encodeURIComponent(this.apiKey);
            }
            else {
                requestOptions.headers['Cookie'] = this.paramName + '=' + encodeURIComponent(this.apiKey);
            }
        }
    }
}

export class OAuth implements Authentication {
    public accessToken: string = '';

    applyToRequest(requestOptions: localVarRequest.Options): void {
        if (requestOptions && requestOptions.headers) {
            requestOptions.headers["Authorization"] = "Bearer " + this.accessToken;
        }
    }
}

export class VoidAuth implements Authentication {
    public username: string = '';
    public password: string = '';

    applyToRequest(_: localVarRequest.Options): void {
        // Do nothing
    }
}

export type Interceptor = (requestOptions: localVarRequest.Options) => (Promise<void> | void);
