const url = 'https://real-time-product-search.p.rapidapi.com/search?q=Nike%20shoes&country=us&language=en';
const options = {
    method: 'GET',
    headers: {
        'X-RapidAPI-Key': 'ff0a6a6dacmshcfcfd7b06e45617p1c996bjsn15bfeac30230',
        'X-RapidAPI-Host': 'real-time-product-search.p.rapidapi.com'
    }
};

try {
    const response = await fetch(url, options);
    const result = await response.text();
    console.log(result);
} catch (error) {
    console.error(error);
}