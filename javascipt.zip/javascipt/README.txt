This program can search for products on google shopping and homedepot and display a table of data
including how far away they are, the time it takes to ship, price, etc. It uses web crawler apis to get raw
data which is fed into the chatgpt api and processed to produce a final result which can be formated as needed
though adjusting the prompt (i.e. place all data in brackets) so that it can be integrated into a web application.

It also features the ability to communicate with the chatbot about whatever questions the user may have, be it what
parts he/she may need or scientific questions. The possibilities are endless.

Last but not least it can encrypt/decrypt a string using AES 256 bit encryption and a RSA 4096 bit encrypted AES key
for dual encryption. This is beyond bank grade security, and with the rise of quantum computing and zero day attacks,
its always better safe then sorry. It still runs quite fast despite all of its encryption, as RSA is used for what its
great at, encrypting keys, and AES is used for encrypting data which it can do quite fast.