import axios from "axios";
// set up the request parameters
const params = {
    api_key: "A3F34E6187AC460CBC83BECB9EC0AF14",
    search_term: "lawn mower",
    type: "search"
}

// make the http GET request to BigBox API
axios.get('https://api.bigboxapi.com/request', { params })
    .then(response => {

        // print the JSON response from BigBox API
        console.log(JSON.stringify(response.data, 0, 2));

    }).catch(error => {
// catch and print the error
    console.log(error);
})